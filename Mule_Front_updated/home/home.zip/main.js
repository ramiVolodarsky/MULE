document.querySelector('.btn-search').addEventListener('click', function(event) {
    event.preventDefault();
    var searchValue = document.querySelector('.search-input').value;

    // Check if searchValue is empty or only contains whitespace
    if (searchValue.trim() === '') {
        // If the input is empty, add the 'error' class to the input
        document.querySelector('.search-input').classList.add('error');

        // Remove the 'error' class after 2 seconds
        setTimeout(function() {
            document.querySelector('.search-input').classList.remove('error');
        }, 2000);
    } else {
        window.location.href = '../search/index.html?q=' + encodeURIComponent(searchValue);
    }
});
